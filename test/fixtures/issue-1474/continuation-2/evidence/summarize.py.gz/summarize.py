from pathlib import Path
import json
p=Path('/tmp/nuinuicad-1474-ts');dest=Path('/Users/yosomi/Code/nuinuiCAD/test/fixtures/issue-1474/continuation-2')
def fmt(s):return '/'.join(f'{s[k]:.3f}' for k in ['p50','p95','max'])
if (p/'complete-timing.json').exists():
 t=json.loads((p/'complete-timing.json').read_text());rows=[];n=[]
 for r in t['records']:
  if 'pair' not in r:continue
  a,b=r['summaries'];ratios={s:b['stageStats'][s]['wallMs']['p50']/a['stageStats'][s]['wallMs']['p50'] for s in ['compile','lowering','rustTransport']}
  norm=(b['graph']['V']+b['graph']['E'])/(a['graph']['V']+a['graph']['E'])
  for v in [a,b]:
   rows.append('| '+r['pair']+' | '+v['id']+' | '+str(v['sourceBytes'])+' | '+str(v['graph']['V'])+'/'+str(v['graph']['E'])+' | '+' | '.join(fmt(v['stageStats'][s]['wallMs']) for s in ['compile','lowering','rustTransport','decode'])+' |')
  n.append(dict(pair=r['pair'],VplusERatio=norm,medianRatios=ratios,normalizedRatios={s:r/norm for s,r in ratios.items()},child=r['child']))
 (dest/'performance-summary.md').write_text('# Final paired stage measurements\n\nMilliseconds p50/p95/max; 5 warmups and 21 alternating paired trials per case. JSON encoding is an additional probe in raw evidence; production transport includes actual encode, Rust evaluation and JSON decoding. Cold/setup excluded.\n\n| Pair | Case | Source bytes | V/E | Compile/graph | Lowering | Rust transport | Result decode |\n| --- | --- | ---: | --- | --- | --- | --- | --- |\n'+'\n'.join(rows)+'\n\nRaw stage CPU, encoding, every sample, owned-child batch CPU and RSS are in complete-timing.json.gz. V+E normalization and child resource observations are in performance-normalized.json. Compact broad/shallow source includes a generated for-group; its small source graph is not comparable to its expanded runtime output count.\n')
 (dest/'performance-normalized.json').write_text(json.dumps(dict(protocol=t['protocol'],setupWallMs=t['setupWallMs'],requests=t['requests'],spawns=t['spawns'],pid=t['pid'],peakRustRssKiB=t['peakRustRssKiB'],workerResourceUsage=t['workerResourceUsage'],comparisons=n),indent=2)+'\n')
 print(json.dumps(dict(requests=t['requests'],peakRustRssKiB=t['peakRustRssKiB'],pairs=[{k:v for k,v in x.items() if k!='child'} for x in n]),indent=2))
