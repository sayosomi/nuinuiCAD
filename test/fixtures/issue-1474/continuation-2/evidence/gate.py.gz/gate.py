from pathlib import Path
import subprocess,os,json
p=Path('/tmp/nuinuicad-1474-ts');root='/Users/yosomi/Code/nuinuiCAD'
commands=[(120,['cargo','fmt','--manifest-path','rust-evaluator/Cargo.toml','--check']),(120,['cargo','check','--manifest-path','rust-evaluator/Cargo.toml']),(240,['cargo','test','--manifest-path','rust-evaluator/Cargo.toml']),(180,['cargo','clippy','--manifest-path','rust-evaluator/Cargo.toml','--all-targets','--','-D','warnings']),(180,['npm','run','build']),(180,['npm','run','lint']),(1800,['npm','test','--','--pool=forks','--maxWorkers=1','--no-file-parallelism']),(300,['npm','run','test:parity']),(600,['npm','run','test:performance:binding-analysis']),(120,['git','diff','--check','60f54f3ccec505821bc615e516bab8192bd20533'])]
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=2048',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='2');results=[]
for i,(limit,cmd) in enumerate(commands,1):
 log=p/f'gate-{i:02}.log'
 if log.exists():raise RuntimeError('refuse to overwrite gate evidence')
 print('GATE',i,json.dumps(cmd),flush=True)
 rc=subprocess.run(['python3',str(p/'run.py'),str(limit),str(log)]+cmd,cwd=root,env=env).returncode
 results.append(json.loads(Path(str(log)+'.result.json').read_text()))
 (p/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if rc:print('GATE STOP',i,rc,flush=True);raise SystemExit(rc)
print('ALL REQUIRED GATES PASS',flush=True)
