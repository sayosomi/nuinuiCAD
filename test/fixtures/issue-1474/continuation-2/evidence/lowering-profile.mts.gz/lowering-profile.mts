import {readFileSync,writeFileSync} from 'node:fs';
import {Session} from 'node:inspector/promises';
import {compileFreshCanonicalText} from '/Users/yosomi/Code/nuinuiCAD/packages/nui-language/src/document/canonicalDocument.ts';
import {buildEvaluationOptions} from '/Users/yosomi/Code/nuinuiCAD/src/geometry/productionEvaluationContext.ts';
import {prepareRustEvaluation} from '/Users/yosomi/Code/nuinuiCAD/src/geometry/rustEvaluationRunner.ts';
const paths=['D2-r1.nui','D3-r1.nui'];const documents=paths.map(p=>compileFreshCanonicalText(readFileSync('/Users/yosomi/Code/nuinuiCAD/test/fixtures/issue-1474/'+p,'utf8')).doc);
const observations=[];const profiler=new Session();profiler.connect();await profiler.post('Profiler.enable');
function run(i){const cpu=process.cpuUsage();const wall=performance.now();const c=documents[i];const p=prepareRustEvaluation(c.document.elements,buildEvaluationOptions({compiledDocument:c,evaluationLimitIndex:undefined}));const ms=performance.now()-wall;const used=process.cpuUsage(cpu);if(!p.rustEligible)throw Error('normal eligibility required');return{wallMs:ms,cpuMs:(used.user+used.system)/1000};}
for(let block=1;block<=4;block++){
 for(let w=0;w<5;w++){run(0);run(1)}
 if(block===4)await profiler.post('Profiler.start');
 const samples=[[],[]];for(let trial=0;trial<21;trial++)for(const i of trial%2?[1,0]:[0,1])samples[i].push(run(i));
 if(block===4){const {profile}=await profiler.post('Profiler.stop');writeFileSync('/tmp/nuinuicad-1474-ts/lowering.cpuprofile',JSON.stringify(profile));}
 const stats=samples.map(s=>{const v=s.map(x=>x.wallMs).sort((a,b)=>a-b);return{p50:v[10],p95:v[19],max:v[20]}});observations.push({block,profiled:block===4,paths,samples,stats});console.log(JSON.stringify({block,stats}));
}
profiler.disconnect();writeFileSync('/tmp/nuinuicad-1474-ts/lowering-paired.json',JSON.stringify({owner:'unchanged Base runtime lowering owner; setup compiled documents outside measurements; no evaluator calls',observations,resourceUsage:process.resourceUsage()},null,2)+'\n');
