from pathlib import Path
import subprocess,json,sys,os
root=Path('/Users/yosomi/Code/nuinuiCAD');os.chdir(root)
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
base='60f54f3ccec505821bc615e516bab8192bd20533';branch='sayosomi/issue-1474-dependency-topology-hunt';expected=sys.argv[1]
assert Path(git('rev-parse','--show-toplevel')).resolve()==root
assert git('branch','--show-current')==branch
assert git('rev-parse','origin/main')==base
assert git('rev-parse','origin/'+branch)==expected
assert 'sayosomi/nuinuiCAD' in git('remote','get-url','origin')
common=Path(git('rev-parse','--git-common-dir')).resolve();impl=Path(git('rev-parse','--absolute-git-dir'));human=Path(subprocess.check_output(['git','-C','/Users/yosomi/Code/nuinuiCAD-e2e','rev-parse','--absolute-git-dir'],text=True).strip())
assert (impl/'nuinui-implementation-v1').read_text()=='version=1\n'
patterns=['nuinui-implementation-slot','nuinui-implementation-lock','nuinui-implementation-slot.releasing.*','nuinui-audit-reservation-v1','nuinui-github-e2e-active-v1','nuinui-github-e2e-starting-v1.*','nuinui-github-e2e-releasing-v1.*']
checked=[]
for directory in set([common,impl,human]):
 for pattern in patterns:
  found=list(directory.glob(pattern));assert not found,(str(directory),pattern,[str(x) for x in found]);checked.append(str(directory/pattern))
print(json.dumps(dict(branch=branch,base=base,localHead=git('rev-parse','HEAD'),remoteTopic=expected,status=git('status','--porcelain','--untracked-files=all'),ownershipMarkersAbsent=checked),indent=2))
