from pathlib import Path
import subprocess,json,os
root=Path('/Users/yosomi/Code/nuinuiCAD'); tmp=Path('/tmp/nuinuicad-1474-ts'); base='60f54f3ccec505821bc615e516bab8192bd20533'
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=2048')
common=['--pool=forks','--maxWorkers=1','--no-file-parallelism','--disableConsoleIntercept']
records=[]
def run(name,paths,cmd,transform=None):
 saved={p:(root/p).read_bytes() for p in paths}
 try:
  for p in paths:
   value=transform(saved[p]) if transform else subprocess.check_output(['git','show',base+':'+p],cwd=root)
   (root/p).write_bytes(value)
  rc=subprocess.run(['python3',str(tmp/'run.py'),'120',str(tmp/(name+'.log'))]+cmd,cwd=root,env=env).returncode
  records.append({'case':name,'exit':rc,'expectedFailure':rc!=0})
  if rc==0: raise RuntimeError('negative sensitivity unexpectedly passed: '+name)
 finally:
  for p,v in saved.items(): (root/p).write_bytes(v)
  assert all((root/p).read_bytes()==v for p,v in saved.items())
run('removed-ts',['src/scalars/declarationEvaluator.ts','src/scalars/expressionEvaluator.ts'],['npx','vitest','run','src/scalars/dependencyResolution.test.ts','-t','eight diamonds']+common)
def without_guards(b):
 s=b.decode()
 for guard in ['        if readiness.candidate_binding_ids.is_empty() {\n            return HashSet::new();\n        }\n','        if candidate_binding_ids.is_empty() {\n            return HashSet::new();\n        }\n','        if state.errors.is_empty() {\n            return false;\n        }\n']:
  assert s.count(guard)==1
  s=s.replace(guard,'')
 return s.encode()
run('removed-readiness',['rust-evaluator/src/evaluation/conditional_dependency_runtime.rs'],['cargo','test','--manifest-path','rust-evaluator/Cargo.toml','empty_','--','--nocapture'],without_guards)
run('removed-naming',['packages/nui-language/src/dsl/dslCompiler.ts','packages/nui-language/src/model/elementFactory.ts'],['npx','vitest','run','src/dsl/dependencyTopologyCompilation.test.ts']+common)
run('removed-lowering',['src/geometry/numericBindingRuntime.ts'],['npx','vitest','run','src/geometry/numericBindingRuntime.integration.test.ts','-t','enumerates compiler numeric bindings']+common)
(tmp/'repair-removal.json').write_text(json.dumps(records,indent=2)+'\n')
