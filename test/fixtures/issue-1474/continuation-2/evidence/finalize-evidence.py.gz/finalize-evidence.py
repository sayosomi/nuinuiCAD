from pathlib import Path
import json,hashlib,subprocess,re
root=Path('/Users/yosomi/Code/nuinuiCAD');tmp=Path('/tmp/nuinuicad-1474-ts');out=root/'test/fixtures/issue-1474/continuation-2'
gates=json.loads((tmp/'gate-accepted-results.json').read_text());assert len(gates)==10 and all(x['exit']==0 and x['stopReason'] is None for x in gates)
identities=json.loads((out/'tested-source-identities.json').read_text())
for r in identities:assert hashlib.sha256((root/r['file']).read_bytes()).hexdigest()==r['sha256'],r['file']
m=json.loads((tmp/'complete-matrix-final.json').read_text());assert len(m['observations'])==28 and all(x['status']=='PASS' for x in m['observations'])
t=json.loads((tmp/'complete-timing.json').read_text());assert t['spawns']==1 and t['requests']==937
paired=[x for x in t['records'] if 'pair' in x];assert len(paired)==18 and all(x['trials']==21 and x['warmups']==5 and all(len(s)==21 for s in x['samples']) for x in paired)
rows=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines();processes={int(r.split(None,2)[0]):r.split(None,2)[2] for r in rows if len(r.split(None,2))==3};pids=set()
for f in tmp.glob('*.json'):
 try:d=json.loads(f.read_text())
 except (ValueError,UnicodeError):continue
 if isinstance(d,dict) and d.get('spawns')==1:
  pid=d.get('childPid') or d.get('pid')
  if isinstance(pid,int):pids.add(pid)
cleanup=[]
for pid in sorted(pids):
 cmd=processes.get(pid);assert not (cmd and 'evaluation_stdio' in cmd),(pid,cmd)
 cleanup.append(dict(pid=pid,state='absent' if cmd is None else 'PID reused by a different process; untouched',currentCommand=cmd))
(out/'process-cleanup.json').write_text(json.dumps(dict(ownedStdioProcesses=cleanup,allKnownOwnedStdioChildrenClosed=True,notes='Campaign hooks dispose and await close; watchdog groups are owned only. The intentional failing npm stop is documented separately. No unrelated process was signaled.'),indent=2)+'\n')
summary={}
for i in [3,7,8,9]:
 text=(tmp/f'gate-accepted-{i:02}.log').read_text();summary[str(i)]=re.findall(r'(?:Test Files|Tests|test result:)[^\n]*',text)
commands=[]
for i,g in enumerate(gates,1):commands.append(dict(g,log=f'evidence/gate-accepted-{i:02}.log.gz'))
verification=dict(status='IMPLEMENTATION_VERIFICATION_PASS_PENDING_INDEPENDENT_REVIEW',base='60f54f3ccec505821bc615e516bab8192bd20533',previousCheckpoint='6c1d56b3e72c1acd1013b1f6c23d0e85aec9d50b',branch='sayosomi/issue-1474-dependency-topology-hunt',primaryUnits=16,reducerSlots=4,conservativeAcceptedUnits=20,ceiling=32,primarySourceRevisions=24,finalMatrixSourceRevisionExecutions=28,uniqueSourceHashes=19,firstIncorrectOwners=5,mechanisms=4,commands=commands,summaries=summary,priorGateStops=[dict(file='gate-results.json.gz',reason='clippy err_expect, corrected with expect_err'),dict(file='gate-final-results.json.gz',reason='host-import-boundary failure in new R3 test; known failing owned npm group intentionally stopped'),dict(file='gate-complete-results.json.gz',reason='Node-only test types after relocation; corrected without changing package configuration')],performance=dict(pairs=18,warmups=5,alternatingTrials=21,requests=t['requests'],spawns=t['spawns'],peakRustRssKiB=t['peakRustRssKiB'],watchdog=json.loads((tmp/'complete-timing.log.result.json').read_text()),normalization='performance-normalized.json',summary='performance-summary.md',residuals='SUSPECT/INCONCLUSIVE remaining B/D scaling and historical for-group control; no additional fix claimed'),safety=dict(noDestructiveBaseReplay=True,noNewCheckout=True,noHeapOrStackLimitIncrease=True,ownedProcessCleanup=True),quota=dict(fiveHour='UNAVAILABLE',weekly='UNAVAILABLE'),integration='No PR, merge, Issue close, roadmap write or main restoration. Exact pushed HEAD is in the Issue checkpoint.')
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(dict(gates=len(commands),summary=summary,cleanup=cleanup),indent=2))
