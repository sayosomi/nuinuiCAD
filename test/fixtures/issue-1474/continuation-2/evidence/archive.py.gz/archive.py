from pathlib import Path
import gzip,json,hashlib,subprocess
p=Path('/tmp/nuinuicad-1474-ts');dest=Path('/Users/yosomi/Code/nuinuiCAD/test/fixtures/issue-1474/continuation-2');ev=dest/'evidence';ev.mkdir(exist_ok=True)
index=[]
for f in sorted(p.iterdir()):
 if not f.is_file() or (f.suffix not in ['.json','.log','.py','.mts','.cpuprofile'] and not f.name.endswith('.sample.txt')):continue
 b=f.read_bytes();out=ev/(f.name+'.gz');gz=gzip.compress(b,mtime=0)
 if out.exists():assert out.read_bytes()==gz,'refuse evidence overwrite '+str(out)
 else:out.write_bytes(gz)
 index.append(dict(file='evidence/'+out.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),gzipSha256=hashlib.sha256(gz).hexdigest()))
(dest/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
base='6c1d56b3e72c1acd1013b1f6c23d0e85aec9d50b';paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'test/fixtures/issue-1474'],text=True).splitlines();preservation=[]
for path in paths:
 old=subprocess.check_output(['git','show',base+':'+path]);actual=Path('/Users/yosomi/Code/nuinuiCAD',path).read_bytes();assert old==actual,path
 preservation.append(dict(file=path,sha256=hashlib.sha256(old).hexdigest(),unchanged=True))
(dest/'preservation.json').write_text(json.dumps(dict(previousCheckpoint=base,count=len(paths),files=preservation),indent=2)+'\n')
print(json.dumps(dict(archived=len(index),preserved=len(paths))))
