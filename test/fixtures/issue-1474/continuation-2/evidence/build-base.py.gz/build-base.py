from pathlib import Path
import subprocess,hashlib,json
base='60f54f3ccec505821bc615e516bab8192bd20533'
paths=['rust-evaluator/src/evaluation/scalars/'+f for f in ['bindings.rs','bindings_tests.rs','expression_evaluator.rs']]
saved={p:Path(p).read_bytes() for p in paths}
try:
 for p in paths:Path(p).write_bytes(subprocess.check_output(['git','show',base+':'+p]))
 assert subprocess.check_output(['git','diff','--name-only',base,'--','rust-evaluator'],text=True)==''
 result=subprocess.run(['cargo','build','--manifest-path','rust-evaluator/Cargo.toml','--target-dir','/tmp/nuinuicad-1474-base-target','--bin','evaluation_stdio'],timeout=120)
 if result.returncode:raise SystemExit(result.returncode)
 b=Path('/tmp/nuinuicad-1474-base-target/debug/evaluation_stdio')
 Path('/tmp/nuinuicad-1474-ts/base-binary.json').write_text(json.dumps({'base':base,'allRustSourcesExactBase':True,'binary':str(b),'sha256':hashlib.sha256(b.read_bytes()).hexdigest()},indent=2)+'\n')
finally:
 for p,data in saved.items():Path(p).write_bytes(data)
 assert all(Path(p).read_bytes()==data for p,data in saved.items())
