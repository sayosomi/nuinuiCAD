from pathlib import Path
import subprocess,os,time,re,json
p=Path('/tmp/nuinuicad-1474-ts');env=dict(os.environ,VITE_RUN_PERFORMANCE_GATES='1',NODE_OPTIONS='--max-old-space-size=2048',ISSUE1474_TIMING_PAIRS='chain250:chain1000',ISSUE1474_TIMING_RECORD=str(p/'control-profile.json'))
cmd=['python3',str(p/'run.py'),'180',str(p/'control-profile.log'),'npx','vitest','run','test/issue1474DependencyTopologyTiming.performance.test.ts','--pool=forks','--maxWorkers=1','--no-file-parallelism','--bail=1','--disableConsoleIntercept']
proc=subprocess.Popen(cmd,cwd='/Users/yosomi/Code/nuinuiCAD',env=env)
start=time.monotonic();sampled=False
while proc.poll() is None:
 text=(p/'control-profile.log').read_text() if (p/'control-profile.log').exists() else ''
 match=re.search(r'timing owned pid=(\d+)',text)
 if match and time.monotonic()-start>12 and not sampled:
  pid=int(match.group(1));print('SAMPLING OWNED CONTROL PID',pid,flush=True)
  s=subprocess.run(['/usr/bin/sample',str(pid),'1','-file',str(p/'control-native.sample.txt')],capture_output=True,text=True,timeout=10)
  (p/'control-sample-command.json').write_text(json.dumps(dict(pid=pid,exit=s.returncode,stdout=s.stdout,stderr=s.stderr),indent=2)+'\n');sampled=True
 time.sleep(.25)
raise SystemExit(proc.returncode)
