import {readFileSync,writeFileSync} from 'node:fs';
import {Session} from 'node:inspector/promises';
import {compileFreshCanonicalText} from '/Users/yosomi/Code/nuinuiCAD/packages/nui-language/src/document/canonicalDocument.ts';
const paths=['B2-r1.nui','B3-r1.nui'];
const sources=paths.map(p=>readFileSync('/Users/yosomi/Code/nuinuiCAD/test/fixtures/issue-1474/'+p,'utf8'));
const observations=[];const profiler=new Session();profiler.connect();await profiler.post('Profiler.enable');
function run(i){const cpu=process.cpuUsage();const wall=performance.now();const c=compileFreshCanonicalText(sources[i]);const ms=performance.now()-wall;const used=process.cpuUsage(cpu);if(c.status==='fatal'||c.diagnostics.length||c.bindingIssueDiagnostics.length)throw Error(JSON.stringify(c.diagnostics));return{wallMs:ms,cpuMs:(used.user+used.system)/1000};}
for(let block=1;block<=4;block++){
 for(let w=0;w<5;w++){run(0);run(1)}
 if(block===4)await profiler.post('Profiler.start');
 const samples=[[],[]];for(let trial=0;trial<21;trial++){for(const i of trial%2?[1,0]:[0,1])samples[i].push(run(i));}
 if(block===4){const {profile}=await profiler.post('Profiler.stop');writeFileSync('/tmp/nuinuicad-1474-ts/compiler-fixed.cpuprofile',JSON.stringify(profile));}
 const stats=samples.map(s=>{const v=s.map(x=>x.wallMs).sort((a,b)=>a-b);return{p50:v[10],p95:v[19],max:v[20]}});observations.push({block,profiled:block===4,paths,samples,stats});console.log(JSON.stringify({block,stats}));
}
profiler.disconnect();writeFileSync('/tmp/nuinuicad-1474-ts/compiler-fixed-paired.json',JSON.stringify({owner:'corrected candidate Language Core compiler, no runtime imports',observations,resourceUsage:process.resourceUsage()},null,2)+'\n');
