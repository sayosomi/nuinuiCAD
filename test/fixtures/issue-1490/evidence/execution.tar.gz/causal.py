import subprocess,json,hashlib,os
from pathlib import Path
root=Path('/Users/yosomi/Code/nuinuiCAD');out=Path('/Users/yosomi/.codex/issue-1490-evidence')
paths=['packages/nui-language/src/dsl/dslDocument.ts','packages/nui-language/src/scalars/moduleScalarRuntime.ts','packages/nui-language/src/scalars/recordScalarLowering.ts']
fixed={p:(root/p).read_bytes() for p in paths}
base={p:subprocess.check_output(['git','show','0c4c2df0f6694645a857734373fb8a3d986a7d41:'+p],cwd=root) for p in paths}
for p in paths:(out/(Path(p).name+'.fixed')).write_bytes(fixed[p])
ledger=[]
def run(label):
 env=dict(os.environ,ISSUE1490_RECORD=str(out/(label+'.json')),ISSUE1490_KEEP_ARTIFACTS='1')
 with (out/(label+'.log')).open('wb') as log:
  result=subprocess.run(['npm','test','--','test/issue1490RenameArtifacts.integration.test.ts','--maxWorkers=1','--no-file-parallelism'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 ledger.append({'label':label,'exitCode':result.returncode,'productionHashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in paths}})
 (out/'causal.json').write_text(json.dumps(ledger,indent=2)+'\n')
 return result.returncode
try:
 for p in paths:(root/p).write_bytes(base[p])
 assert run('exact-Base')==1
 for p in paths:(root/p).write_bytes(fixed[p])
 assert run('all-fixed')==0
 for family in ['F1','F2','F3']:
  if family=='F1':(root/paths[0]).write_bytes(base[paths[0]])
  elif family=='F2':(root/paths[2]).write_bytes(base[paths[2]])
  else:
   s=fixed[paths[1]].decode();new='''initializers.set(bindingId, remapTypedExpressionCollectionValueIds(
          remapTypedExpressionSourceOrders(initializer, (sourceOrder) => sourceOrder >= 0 ? executionPositionForValue([], sourceOrder) : sourceOrder),
          (valueId) => collectionValueIdFor(valueId, null)
        ));''';old='initializers.set(bindingId, remapTypedExpressionCollectionValueIds(initializer, (valueId) => collectionValueIdFor(valueId, null)));'
   assert s.count(new)==1
   (root/paths[1]).write_text(s.replace(new,old))
  assert run(family+'-removed')==1
  for p in paths:(root/p).write_bytes(fixed[p])
  assert run(family+'-restored')==0
finally:
 for p in paths:(root/p).write_bytes(fixed[p])
 assert all((root/p).read_bytes()==fixed[p] for p in paths)
