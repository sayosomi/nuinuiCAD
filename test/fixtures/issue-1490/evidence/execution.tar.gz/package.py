from pathlib import Path
import json,gzip,hashlib,tarfile,re,subprocess
root=Path('/Users/yosomi/Code/nuinuiCAD');raw=Path('/Users/yosomi/.codex/issue-1490-evidence');dest=root/'test/fixtures/issue-1490/evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((raw/'final-matrix.json').read_text());matrix=json.loads((root/'test/fixtures/issue-1490/matrix.json').read_text())
rows=[x for x in result['records'] if 'artifacts' in x]
artifacts=[]
with tarfile.open(dest/'artifacts.tar.gz','w:gz')as archive:
 for row in rows:
  for key in ['artifacts','secondArtifacts','restored','recovered']:
   for a in row.get(key,[]):
    file=Path(a['path']);data=file.read_bytes();assert sha(data)==a['sha256']
    archive.add(file,arcname=file.name);artifacts.append({**a,'path':file.name})
summary={'base':'0c4c2df0f6694645a857734373fb8a3d986a7d41','branch':'sayosomi/issue-1490-public-module-rename-record-artifact-hunt','acceptedUnits':17,'primary':12,'adjacent':{'accepted':['X1','X2'],'rejected':0,'NOT_TRIGGERED':['X3','X4','X5','X6','X7','X8']},'reducers':{'accepted':['M1','M2','M3'],'rejected':0,'NOT_TRIGGERED':['M4','M5','M6','M7','M8']},'rejectedPrevalidationDrafts':0,'deliberateNegativeControls':20,'faultSeedAssertions':63,'process':{k:result[k]for k in ['spawns','requests','exports']},'prevalidation':{'sourceSnapshots':sum('prevalidation'in r for r in result['records']),'allLegal':all(not r['errors'] for r in result['records']if 'prevalidation'in r)},'primaryResults':[],'families':[
 {'id':'F1','firstOwner':'packages/nui-language/src/dsl/dslDocument.ts additionalRecordPropertyResolver','cause':'Root scalar constructor-field read used record-field-contents for the entire path instead of contents prefix plus record-field-collection projection, disagreeing with the existing producer. Reuses indexedRecordFieldPaths from moduleScalarRuntime.','reproducer':'M1','neighbor':'X2','affected':['R4-S0','R4-S1','R4-S2','M1','M2','X1']},
 {'id':'F2','firstOwner':'packages/nui-language/src/scalars/recordScalarLowering.ts planRecordScalarLowering','cause':'Inline members of an array-only record wrapper reserved slot zero although no named array binding owned it, producing a sourceOrder hole and bindingCatalog exception. Reserve only for actual named collection values.','reproducer':'M2','neighbor':'X2','affected':['X1','M2']},
 {'id':'F3','firstOwner':'packages/nui-language/src/scalars/moduleScalarRuntime.ts compileModuleScalarRuntime document initializer fallback','cause':'Fallback synthetic record scalar initializers remapped collection IDs but retained authored targetSourceOrder rather than the canonical runtime event position; Rust rejected legal accesses. Existing source-order remapper fixes the producer without Rust changes.','reproducer':'M3','neighbor':'X2','affected':['M1','M2','M3','X1']}], 'limitations':['Structured host/provider discovery and host-neutral Canvas/Module Preview tested; no native GUI execution.','Human-only E2E Not Required; production native host/provider/save path unchanged.','Protected independent pushed-HEAD review, PR/CI, merge and Human clean-main restoration remain external completion gates.'],'quota':{'humanWeekly':'UNAVAILABLE','humanFiveHour':'UNAVAILABLE'}}
for row in rows:
 cell=next(c for c in matrix if c['id']==row['id'])
 entry={k:v for k,v in row.items()if k not in ['reference','geometry','artifacts','secondArtifacts','restored','recovered']}
 entry['bundleSha256']=sha(json.dumps(cell['files'],sort_keys=True,separators=(',',':')).encode())
 entry['actualGeometry']=row['geometry']
 for k in ['artifacts','secondArtifacts','restored','recovered']:
  if k in row:entry[k]=[{**a,'path':Path(a['path']).name}for a in row[k]]
 summary['primaryResults'].append(entry)
summary['artifactArchive']={'files':len(artifacts),'sha256':sha((dest/'artifacts.tar.gz').read_bytes())}
(dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
(dest/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
(dest/'causal.json').write_bytes((raw/'causal.json').read_bytes())
for name in ['base.log','base-harness-corrected.log','reducer-base.log','neighbor-base.log','F1-fixed.log','F2-fixed-F3-base.log','fixed-first.log','exact-Base.log','all-fixed.log','F1-removed.log','F1-restored.log','F2-removed.log','F2-restored.log','F3-removed.log','F3-restored.log','focused-owner.log','historical.log','final-matrix.log']:
 (dest/(name+'.gz')).write_bytes(gzip.compress((raw/name).read_bytes(),mtime=0))
# Full prepared/reference/Rust evidence is retained only for the original
# independent reducers and their corrected final counterparts, not every rerun.
for name in ['reducer-base.json','F2-fixed-F3-base.json']:
 (dest/(name+'.gz')).write_bytes(gzip.compress((raw/name).read_bytes(),mtime=0))
causal=[]
for item in json.loads((raw/'causal.json').read_text()):
 log=(raw/(item['label']+'.log')).read_text()
 causal.append({**item,'tests':re.findall(r'Tests\s+([^\n]+)',log)[-1:], 'failedNames':re.findall(r' FAIL  [^\n]+',log)})
(dest/'causal.json').write_text(json.dumps(causal,indent=2)+'\n')
with tarfile.open(dest/'execution.tar.gz','w:gz')as archive:
 for f in ['causal.py','package.py']:archive.add(raw/f,arcname=f)
print('packaged',len(rows),'primary results;',len(artifacts),'actual files;',summary['process'])
