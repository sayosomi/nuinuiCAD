import subprocess,json,os
from pathlib import Path
out=Path('test/fixtures/issue-1468/evidence');results=[]
# Exactly three predeclared iterations; every one must pass. No retry logic.
for i in range(1,4):
 env=dict(os.environ,ISSUE1468_RECORD=str((out/f'focused-{i}.json').resolve()))
 with (out/f'focused-{i}.log').open('w') as f:
  r=subprocess.run(['npm','test','--','test/issue1468PatternWorkflow.integration.test.ts','src/vscode/modulePreviewEvaluation.test.ts','src/dsl/modulePreviewRoot.test.ts','src/dsl/moduleMaterialization.test.ts','--maxWorkers=1','--no-file-parallelism'],stdout=f,stderr=subprocess.STDOUT,timeout=180,env=env)
 results.append({'iteration':i,'exitCode':r.returncode});print(json.dumps(results[-1]),flush=True)
 (out/'focused-repetitions.json').write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode:print((out/f'focused-{i}.log').read_text()[-5000:]);raise SystemExit(r.returncode)
