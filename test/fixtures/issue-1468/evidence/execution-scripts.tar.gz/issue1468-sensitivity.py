import os,json,subprocess
from pathlib import Path
base='c7ae3500f16d6e17dfb7bffd57365c967e1c4e5c';out=Path('test/fixtures/issue-1468/evidence');summary=[]
for family,file,selection in [('F1','src/vscode/modulePreviewEvaluation.ts','R1 source-scope'),('F2','src/dsl/modulePreviewRoot.ts',"'R2'"),('F3','packages/nui-language/src/dsl/dslCompiler.ts',"'R3'")]:
 p=Path(file);candidate=p.read_bytes()
 try:
  p.write_bytes(subprocess.check_output(['git','show',base+':'+file]))
  env=dict(os.environ,ISSUE1468_RECORD=str((out/f'mutation-{family}.json').resolve()))
  r=subprocess.run(['npm','test','--','test/issue1468PatternWorkflow.integration.test.ts','-t',selection,'--maxWorkers=1','--no-file-parallelism'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env,timeout=180)
  (out/f'mutation-{family}.log').write_text(r.stdout)
  summary.append({'family':family,'removedOwnerCorrection':file,'selection':selection,'exitCode':r.returncode,'detected':r.returncode==1})
  print(family,r.returncode,r.stdout[-2200:]);assert r.returncode==1
 finally:p.write_bytes(candidate)
(out/'sensitivity.json').write_text(json.dumps(summary,indent=2)+'\n')
print('All owned candidates restored; three independent removal sensitivities detected')
