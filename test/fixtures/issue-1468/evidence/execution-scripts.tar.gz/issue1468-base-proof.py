import os,json,subprocess,hashlib
from pathlib import Path
base='c7ae3500f16d6e17dfb7bffd57365c967e1c4e5c'
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert files==['packages/nui-language/src/dsl/dslCompiler.ts','packages/nui-language/src/dsl/dslDocument.ts','packages/nui-language/src/scalars/scalarProgram.ts','src/dsl/modulePreviewRoot.ts','src/vscode/modulePreviewEvaluation.ts']
backup={f:Path(f).read_bytes() for f in files}
evidence=Path('test/fixtures/issue-1468/evidence');evidence.mkdir(exist_ok=True)
try:
 for f in files:Path(f).write_bytes(subprocess.check_output(['git','show',base+':'+f]))
 assert not subprocess.check_output(['git','diff',base,'--',*files],text=True)
 env=dict(os.environ,ISSUE1468_RECORD=str(evidence.resolve()/'base.json'))
 r=subprocess.run(['npm','test','--','test/issue1468PatternWorkflow.integration.test.ts','--maxWorkers=1','--no-file-parallelism'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env,timeout=180)
 (evidence/'base.log').write_text(r.stdout)
 (evidence/'base-proof.json').write_text(json.dumps({'base':base,'productionFilesEqualBase':files,'exitCode':r.returncode,'testSealHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n')
 print(r.stdout[-10500:]);assert r.returncode==1
finally:
 for f,data in backup.items():Path(f).write_bytes(data)
 assert all(Path(f).read_bytes()==data for f,data in backup.items())
 print('Owned production candidate restored byte-for-byte; no checkout/branch transition')
